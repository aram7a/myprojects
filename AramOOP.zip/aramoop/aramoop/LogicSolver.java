import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class LogicSolver {
	private List<Character> varNames;
	private List<Integer> varValues;
	private Gate and, or, not;

	public LogicSolver(String varsFileName) throws FileNotFoundException {
		varNames = new ArrayList<>();
		varValues = new ArrayList<>();
		and = new And();
		or = new Or();
		not = new Not();
		initVars(new File(varsFileName));
	}
//read from variables File
	private void initVars(File file) throws FileNotFoundException {
		Scanner input = new Scanner(file);
		while (input.hasNext()) {
			String[] data = input.nextLine().split("=");
			varNames.add(data[0].charAt(0));
			varValues.add(Integer.parseInt(data[1]));
		}
		input.close();
	}
//read from expression file in postfix way
	public int evalExp(String exp) {
		String postfix = toPostfix(exp);
		Stack<Integer> operands = new Stack<>();
		for (char c : postfix.toCharArray()) {
			if (Character.isDigit(c)) {
				operands.push(Character.getNumericValue(c));
			} else if (c == '+') {
				operands.push(or.evalInput(operands.pop(), operands.pop()));
			} else if (c == '.') {
				operands.push(and.evalInput(operands.pop(), operands.pop()));
			} else if (c == '~') {
				operands.push(not.evalInput(operands.pop()));
			} else {
				throw new IllegalArgumentException("Invalid character in expression: " + c);
			}
		}
		return operands.pop();
	}
//convert the expression from infix to postfix
	private String toPostfix(String infix) {
		Stack<Character> operators = new Stack<>();
		StringBuilder postfix = new StringBuilder();
		int i = 0;
		while (i < infix.length()) {
			char ch = infix.charAt(i++);
			if (Character.isLetter(ch)) {
				ch = getVal(ch);
			}
			switch (ch) {
				case '0':
				case '1':
					postfix.append(ch);
					break;
				case '~':
				case '+':
				case '.':
					while (!operators.isEmpty() && precedence(ch) <= precedence(operators.peek()))
						postfix.append(operators.pop());
					operators.push(ch);
					break;
				case '(':
					operators.push(ch);
					break;
				case ')':
					char topOperator = operators.pop();
					while (topOperator != '(') {
						postfix.append(topOperator);
						topOperator = operators.pop();
					}
					break;
				default:
					break;
			}
		}
		while (!operators.isEmpty()) {
			postfix.append(operators.pop());
		}
		return postfix.toString();
	}

	private char getVal(char ch) {
		int index = varNames.indexOf(ch);
		if (index != -1) {
			return (char) ('0' + varValues.get(index));
		}
		return ch;
	}

//define the priorities
	private int precedence(Character op) {
		switch (op) {
			case '~':
				return 3;
			case '.':
				return 2;
			case '+':
				return 1;
			default:
				return 0;
		}
	}

//to print just the variables the user used in the expression
	public Set<Character> getVarsUsed(String exp) {
		Set<Character> usedVars = new HashSet<>();
		for (char c : exp.toCharArray()) {
			if (Character.isLetter(c)) {
				usedVars.add(c);
			}
		}
		return usedVars;
	}

//reconstructing variables and their values
	public String[] getVarValues(Set<Character> variables) {
		List<String> values = new ArrayList<>();
		for (char c : variables) {
			values.add(varNames.get(c - 'p') + "=" + varValues.get(c - 'p'));
		}
		return values.toArray(new String[0]);
	}
}

