
public class And extends Gate {
	public And() {
		super("AND");
	}

	@Override
	public int evalInput(int... inputs) { // there will be only 2 inputs
		return inputs[0] & inputs[1];
	}

	@Override
	public String getDescription() {
		return "This is an AND gate.";
	}
}
