public class Or extends Gate {
	public Or() {
		super("OR");
	}

	@Override
	public int evalInput(int... inputs) { // there will be only 2 inputs
		return inputs[0] | inputs[1];
	}

	@Override
	public String getDescription() {
		return "This is an OR gate.";
	}
}
