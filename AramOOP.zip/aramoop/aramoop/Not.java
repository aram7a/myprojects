public class Not extends Gate {
	public Not() {
		super("NOT");
	}

	@Override
	public int evalInput(int... inputs) { // there will be only 1 input
		return ~inputs[0];
	}

	@Override
	public String getDescription() {
		return "This is a NOT gate.";
	}
}
