import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;

public class Main {
	public static void main(String[] args) {
		try {
			String logicalVarFileName = "Vars.txt";
			LogicSolver solver = new LogicSolver(logicalVarFileName);

			evaluateExpressions(new File("exp.txt"), solver);
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
	}

	private static void evaluateExpressions(File file, LogicSolver solver) {
		try {
			Scanner input = new Scanner(file);
			while (input.hasNext()) {
				String expression = input.nextLine();
				Set<Character> usedVars = solver.getVarsUsed(expression);
				String[] varValues = solver.getVarValues(usedVars);
				System.out.print("Variables: ");
				for (int i = 0; i < varValues.length; i++) {
					System.out.print(varValues[i]);
					if (i < varValues.length - 1) {
						System.out.print(", ");
					}
				}
				System.out.print(" => ");
				int result = solver.evalExp(expression);
				System.out.println(expression + " = " + result);
			}
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
	}
}



















