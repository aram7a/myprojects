public class LogicExpressionPrinter {
    public static void printExpression(String exp) {
        System.out.println("Expression: " + exp);
        System.out.println("Formatted: " + formatExpression(exp));
        System.out.println();
    }

    private static String formatExpression(String exp) {
        StringBuilder formattedExp = new StringBuilder();
        for (char c : exp.toCharArray()) {
            if (Character.isLetter(c)) {
                formattedExp.append(getVarName(c));
            } else {
                formattedExp.append(c);
            }
        }
        return formattedExp.toString();
    }

    private static String getVarName(char c) {
        // Assuming variables are named as p, q, r, ...
        return "Var_" + c;
    }
}
