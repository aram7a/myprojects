public abstract class Gate {
	private String type;

	public Gate(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}

	public abstract int evalInput(int... inputs);

	public abstract String getDescription();
}











