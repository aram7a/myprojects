/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aramalshahateet;

/**
 *
 * @author hp
 */
public class Admin extends User{
    private int id;

    public Admin(int id, String username, String password, String emial) {
        super(username, password, emial);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Admin\n" + super.toString()+"id=" + id + '}';
    }
    
    
    
}
