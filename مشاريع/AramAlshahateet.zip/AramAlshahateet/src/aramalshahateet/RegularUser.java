/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aramalshahateet;

/**
 *
 * @author hp
 */
public class RegularUser extends User {
    private int admainId;

    public RegularUser(int admainId, String username, String password, String emial) {
        super(username, password, emial);
        this.admainId = admainId;
    }

    public int getAdmainId() {
        return admainId;
    }

    public void setAdmainId(int admainId) {
        this.admainId = admainId;
    }

    @Override
    public String toString() {
        return super.toString()+ "admainId=" + admainId ;
    }
    
}
