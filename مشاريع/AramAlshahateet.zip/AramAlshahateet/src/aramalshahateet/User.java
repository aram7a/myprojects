/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aramalshahateet;

/**
 *
 * @author hp
 */
public abstract class User {
    private String username,password,emial;

    public User(String username, String password, String emial) {
        this.username = username;
        this.password = password;
        this.emial = emial;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmial() {
        return emial;
    }

    public void setEmial(String emial) {
        this.emial = emial;
    }

    @Override
    public String toString() {
        return   "username=" + username + "\n password=" + password + "\n emial=" + emial ;
    }
    
}
