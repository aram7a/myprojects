/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aramproj2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class BooleanExpressionDrawer extends JFrame {
    private JTextField equationInput;
    private JTextArea resultArea;
    private Map<Character, Boolean> variableValues = new HashMap<>();
    private JPanel drawPanel;

    public BooleanExpressionDrawer() {
        setTitle("Logic Circuit Visualizer");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        equationInput = new JTextField(30);
        JButton submitButton = new JButton("Submit");

        inputPanel.add(new JLabel("Enter Logic Equation: "));
        inputPanel.add(equationInput);
        inputPanel.add(submitButton);

        resultArea = new JTextArea(5, 40);
        resultArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(resultArea);

        drawPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawCircuit(g);
            }
        };
        drawPanel.setPreferredSize(new Dimension(800, 400));

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(drawPanel, BorderLayout.SOUTH);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String equation = equationInput.getText();
                if (!equation.isEmpty()) {
                    getVariableValues(equation);
                    boolean result = evaluateEquation(equation);
                    displayResult(equation, result);
                    drawPanel.repaint();
                }
            }
        });
    }

    private void getVariableValues(String equation) {
        variableValues.clear();
        for (char c : equation.toCharArray()) {
            if (Character.isLetter(c) && !variableValues.containsKey(c)) {
                String value = JOptionPane.showInputDialog("Enter value for " + c + " (true/false):");
                variableValues.put(c, Boolean.parseBoolean(value));
            }
        }
    }

    private boolean evaluateEquation(String equation) {
        for (Map.Entry<Character, Boolean> entry : variableValues.entrySet()) {
            equation = equation.replace(entry.getKey().toString(), entry.getValue().toString());
        }
        return evaluate(equation);
    }

    private boolean evaluate(String equation) {
        if (equation.contains("(")) {
            int start = equation.lastIndexOf('(');
            int end = equation.indexOf(')', start);
            String subEquation = equation.substring(start + 1, end);
            boolean subResult = evaluate(subEquation);
            equation = equation.substring(0, start) + subResult + equation.substring(end + 1);
            return evaluate(equation);
        }

        if (equation.contains("~")) {
            int index = equation.indexOf('~');
            boolean value = Boolean.parseBoolean(equation.substring(index + 1, index + 5));
            return !value;
        }

        if (equation.contains(".")) {
            String[] parts = equation.split("\\.");
            return Boolean.parseBoolean(parts[0]) && Boolean.parseBoolean(parts[1]);
        }

        if (equation.contains("+")) {
            String[] parts = equation.split("\\+");
            return Boolean.parseBoolean(parts[0]) || Boolean.parseBoolean(parts[1]);
        }

        return Boolean.parseBoolean(equation);
    }

    private void displayResult(String equation, boolean result) {
        StringBuilder sb = new StringBuilder();
        sb.append("Logic Circuit for equation: ").append(equation).append("\n\n");
        for (Map.Entry<Character, Boolean> entry : variableValues.entrySet()) {
            sb.append("Input ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }
        sb.append("\nOutput: ").append(result).append("\n");

        resultArea.setText(sb.toString());
    }

    private void drawCircuit(Graphics g) {
        String equation = equationInput.getText();
        if (!equation.isEmpty()) {
            drawGates(g, equation, 50, 100);
        }
    }

    private int drawGates(Graphics g, String equation, int x, int y) {
        Stack<Gate> gateStack = new Stack<>();
        int offsetX = 0;
        int offsetY = 0;

        for (char c : equation.toCharArray()) {
            switch (c) {
                case '~':
                    Gate notGate = new NotGate(x + offsetX, y + offsetY);
                    notGate.draw(g);
                    gateStack.push(notGate);
                    offsetX += notGate.getWidth() + 20;
                    break;
                case '.':
                    Gate andGate = new AndGate(x + offsetX, y + offsetY);
                    andGate.draw(g);
                    gateStack.push(andGate);
                    offsetX += andGate.getWidth() + 20;
                    break;
                case '+':
                    Gate orGate = new OrGate(x + offsetX, y + offsetY);
                    orGate.draw(g);
                    gateStack.push(orGate);
                    offsetX += orGate.getWidth() + 20;
                    break;
                default:
                    if (Character.isLetter(c)) {
                        g.setColor(Color.black);
                        g.drawString(Character.toString(c), x + offsetX, y + offsetY + 15);
                        offsetX += 20;
                    }
                    break;
            }
        }

        return offsetX;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BooleanExpressionDrawer().setVisible(true);
            }
        });
    }
}
