/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aramproj2;

import java.awt.Graphics;

/**
 *
 * @author hp
 */

abstract class Gate {
    protected int x, y;

    public Gate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract void draw(Graphics g);

    public abstract int getWidth();
}


