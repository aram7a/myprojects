/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aramproj2;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author hp
 */
class OrGate extends Gate {
    public OrGate(int x, int y) {
        super(x, y);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.blue);
        g.drawLine(x - 20, y + 10, x + 20, y + 10);
        g.drawLine(x - 20, y + 30, x + 20, y + 30);
        g.drawArc(x - 20, y, 50, 40, -90, 180);
        g.drawLine(x + 5, y, x + 40, y);
        g.drawLine(x + 5, y + 40, x + 40, y + 40);
        g.drawArc(x + 10, y, 50, 40, -90, 180);
        g.drawLine(x + 60, y + 20, x + 80, y + 20);
    }

    @Override
    public int getWidth() {
        return 80;
    }
}

