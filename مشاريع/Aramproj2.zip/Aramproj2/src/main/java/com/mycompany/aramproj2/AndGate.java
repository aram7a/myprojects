/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aramproj2;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author hp
 */

class AndGate extends Gate {
    public AndGate(int x, int y) {
        super(x, y);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.blue);
        g.fillRect(x, y, 30, 40);
        g.fillRoundRect(x, y, 55, 40, 30, 40);
        g.drawLine(x - 20, y + 10, x, y + 10);
        g.drawLine(x - 20, y + 30, x, y + 30);
        g.drawLine(x + 55, y + 20, x + 80, y + 20);
    }

    @Override
    public int getWidth() {
        return 80;
    }
}

