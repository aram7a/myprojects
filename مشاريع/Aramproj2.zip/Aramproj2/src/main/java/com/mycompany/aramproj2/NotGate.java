/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aramproj2;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author hp
 */

class NotGate extends Gate {
    public NotGate(int x, int y) {
        super(x, y);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.blue);
        g.drawLine(x - 20, y + 20, x, y + 20);
        int[] xPoints = {x, x + 30, x};
        int[] yPoints = {y, y + 20, y + 40};
        g.fillPolygon(xPoints, yPoints, 3);
        g.drawOval(x + 30, y + 15, 10, 10);
        g.drawLine(x + 40, y + 20, x + 50, y + 20);
    }

    @Override
    public int getWidth() {
        return 50;
    }
}

